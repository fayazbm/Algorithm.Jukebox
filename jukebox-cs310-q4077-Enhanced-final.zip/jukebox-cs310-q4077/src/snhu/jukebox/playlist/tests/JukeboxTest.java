package snhu.jukebox.playlist.tests;

import static org.junit.Assert.*;
import java.util.ArrayList;
import org.junit.Test;
import music.artist.*;
import snhu.jukebox.playlist.Song;

public class JukeboxTest {

	@Test
	public void testGetBeatlesAlbumSize() throws NoSuchFieldException, SecurityException {
		 TheBeatles theBeatlesBand = new TheBeatles();
		 ArrayList<Song> beatlesTracks = new ArrayList<Song>();
		 beatlesTracks = theBeatlesBand.getBeatlesSongs();
		 assertEquals(2, beatlesTracks.size());
	}
	
	@Test
	public void testGetImagineDragonsAlbumSize() throws NoSuchFieldException, SecurityException {
		 ImagineDragons imagineDragons = new ImagineDragons();
		 ArrayList<Song> imagineDragonsTracks = new ArrayList<Song>();
		 imagineDragonsTracks = imagineDragons.getImagineDragonsSongs();
		 assertEquals(3, imagineDragonsTracks.size());
	}
	
	@Test
	public void testGetAdelesAlbumSize() throws NoSuchFieldException, SecurityException {
		 Adele adele = new Adele();
		 ArrayList<Song> adelesTracks = new ArrayList<Song>();
		 adelesTracks = adele.getAdelesSongs();
		 assertEquals(3, adelesTracks.size());
	}

	@Test
	public void testGetPigAlbumSize() throws NoSuchFieldException, SecurityException {
		 Pig pig = new Pig();
		 ArrayList<Song> pigTracks = new ArrayList<Song>();
		 pigTracks = pig.getPigSongs();
		 assertEquals(3, pigTracks.size());
	}
	
	@Test
	public void testGetNightClubAlbumSize() throws NoSuchFieldException, SecurityException {
		 NightClub nightClub = new NightClub();
		 ArrayList<Song> nightClubTracks = new ArrayList<Song>();
		 nightClubTracks = nightClub.getNightClubSongs();
		 assertEquals(2, nightClubTracks.size());
	}
	
	@Test
	public void testGetU2AlbumSize() throws NoSuchFieldException, SecurityException {
		 U2 u2 = new U2();
		 ArrayList<Song> u2Tracks = new ArrayList<Song>();
		 u2Tracks = u2.getU2Songs();
		 assertEquals(4, u2Tracks.size());
	}
	
	@Test
	public void testGetSoundgardenAlbumSize() throws NoSuchFieldException, SecurityException {
		 SoundGarden soundgarden = new SoundGarden();
		 ArrayList<Song> soundgardenTracks = new ArrayList<Song>();
		 soundgardenTracks = soundgarden.getSoundGardenSongs();
		 assertEquals(4, soundgardenTracks.size());
	}
	
	@Test
	public void testGetMaroon5AlbumSize() throws NoSuchFieldException, SecurityException {
		 Maroon5 maroon5 = new Maroon5();
		 ArrayList<Song> maroon5Tracks = new ArrayList<Song>();
		 maroon5Tracks = maroon5.getMaroon5Songs();
		 assertEquals(3, maroon5Tracks.size());
	}
	
	@Test
	public void testGetBrunoMarsAlbumSize() throws NoSuchFieldException, SecurityException {
		 BrunoMars brunoMars = new BrunoMars();
		 ArrayList<Song> brunoMarsTracks = new ArrayList<Song>();
		 brunoMarsTracks = brunoMars.getBrunoMarsSongs();
		 assertEquals(2, brunoMarsTracks.size());
	}
	
	@Test
	public void testEricChurchAlbumSize() throws NoSuchFieldException, SecurityException {
		EricChurch ericChurch = new EricChurch();					//Instantiate Eric Church class
		ArrayList<Song> ericChurchTracks = new ArrayList<Song>();	//Instantiate Song Array List
		ericChurchTracks = ericChurch.getEricChurchSongs();			//Get All Songs For Erich Church
		assertEquals(2, ericChurchTracks.size());					//Check that there are two Eric Church songs available
	}
	
	@Test
	public void testTheMarcusKingBandAlbumSize() throws NoSuchFieldException, SecurityException {
		TheMarcusKingBand theMarcusKingBand = new TheMarcusKingBand();					//Instantiate The Marcus King Band class
		ArrayList<Song> theMarcusKingBandTracks = new ArrayList<Song>();				//Instantiate Song Array List
		theMarcusKingBandTracks = theMarcusKingBand.getTheMarcusKingBandSongs();		//Get All Songs For The Marcus King Band
		assertEquals(3, theMarcusKingBandTracks.size());								//Check that there are three The Marcus King Band songs available
	}
	
	@Test
	public void testQueenAlbumSize() throws NoSuchFieldException, SecurityException {
		Queen queen = new Queen();														//Instantiate Queen class
		ArrayList<Song> queenTracks = new ArrayList<Song>();							//Instantiate Song Array List
		queenTracks = queen.getQueenSongs();											//Get All Songs Queen
		assertEquals(2, queenTracks.size());											//Check that there are two Queen songs available
	}
	
	/*
	 * Testing how many songs are retrieved for The Chainsmokers
	 * Expected = 2
	 * */
	@Test
	public void testTheChainsmokersAlbumSize() throws NoSuchFieldException, SecurityException {
		TheChainsmokers theChainsmokers = new TheChainsmokers();														//Instantiate Queen class
		ArrayList<Song> theChainsmokersTracks = new ArrayList<Song>();							//Instantiate Song Array List
		theChainsmokersTracks = theChainsmokers.getTheChainsmokersSongs();											//Get All Songs Queen
		assertEquals(2, theChainsmokersTracks.size());											//Check that there are two Queen songs available
	}
	/*
	 * Testing how many songs are retrieved for The Coldplay
	 * Expected = 3
	 * */
	
	@Test
	public void testColdPlayAlbumSize() throws NoSuchFieldException, SecurityException {
		Coldplay coldplay = new Coldplay();														//Instantiate Queen class
		ArrayList<Song> coldplayTracks = new ArrayList<Song>();							//Instantiate Song Array List
		coldplayTracks = coldplay.getColdplaySongs();											//Get All Songs Queen
		assertEquals(3, coldplayTracks.size());											//Check that there are two Queen songs available
	}
	public void testMotorheadAlbumSize() throws NoSuchFieldException, SecurityException {
		Motorhead motorhead = new Motorhead();														//Instantiate Motorhead class
		ArrayList<Song> motorheadTracks = new ArrayList<Song>();							//Instantiate Song Array List
		motorheadTracks = motorhead.getMotorheadSongs();											//Get All Songs Motorhead
		assertEquals(2, motorheadTracks.size());											//Check that there are two Motorhead songs available
	}
	@Test
	public void testBlackSabbathAlbumSize() throws NoSuchFieldException, SecurityException {
		BlackSabbath blackSabbathBand = new BlackSabbath();
		ArrayList<Song> blackSabbathTracks = new ArrayList<Song>();
		blackSabbathTracks = blackSabbathBand.getBlackSabbathSongs();								//Get All Songs Black Sabbath
		assertEquals(3, blackSabbathTracks.size());											//Check that there are three Black Sabbath songs available
	}
	@Test
	public void testGreenDayAlbumSize() throws NoSuchFieldException, SecurityException {
		GreenDay greenDay = new GreenDay();													//Instantiate GreenDay class
		ArrayList<Song> greenDayTracks = new ArrayList<Song>();								//Instantiate Song Array List
		greenDayTracks = greenDay.getGreenDaySongs();										//Get All Songs GreenDay
		assertEquals(2, greenDayTracks.size());												//Check that there are two GreenDay songs available
	}
	@Test
	public void testNickelbackAlbumSize() throws NoSuchFieldException, SecurityException {
		Nickelback nickelback = new Nickelback();											//Instantiate Nickelback class
		ArrayList<Song> nickelbackTracks = new ArrayList<Song>();							//Instantiate Song Array List
		nickelbackTracks = nickelback.getNickelbackSongs();									//Get All Songs Nickelback
		assertEquals(2, nickelbackTracks.size());											//Check that there are two Nickelback songs available
	}
}
