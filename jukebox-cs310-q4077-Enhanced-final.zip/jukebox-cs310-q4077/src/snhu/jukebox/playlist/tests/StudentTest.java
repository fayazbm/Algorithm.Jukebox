package snhu.jukebox.playlist.tests;

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import snhu.jukebox.playlist.Student;
import snhu.jukebox.playlist.StudentList;
import snhu.student.playlists.*;


public class StudentTest {

	//Test the list of student names and ensure we get back the name value we expect at the correct/specific point in the list
	@Test
	public void testGetStudentNameList1() {
		List<String> studentNames = new ArrayList<String>();							//create variable for student list of names
		StudentList studentList = new StudentList();									//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();									//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("TestStudent1Name", studentNames.get(0));							//test case for pass/fail. We expect the first name to be TestStudent1Name. Remember arrays start their count at 0 not 1.
	}
	
	@Test
	public void testGetStudentNameList2() {
		List<String> studentNames = new ArrayList<String>();							//create variable for student list of names
		StudentList studentList = new StudentList();									//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();									//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("TestStudent2Name", studentNames.get(1));							//test case to see if the second value contains the name we expect
	}
	
	//Module 5 - Add your unit test case here to check for your name after you have added it to the StudentList
	
	@Test
	public void testGetStudentNameList3() {
		List<String> studentNames = new ArrayList<String>();							//create variable for student list of names
		StudentList studentList = new StudentList();									//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();									//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("Stephan Berry", studentNames.get(2));								//test case to see if the third value contains the name we expect
	}
	
	@Test
	public void testGetChrisAubutList() {
		List<String> studentNames = new ArrayList<String>();							//create variable for student list of names
		StudentList studentList = new StudentList();									//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();									//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("Chris Aubut", studentNames.get(3));								//test case for pass/fail. We expect the first name to be TestStudent1Name. Remember arrays start their count at 0 not 1.
	}
	
	@Test
	public void testGetElizabethLockhartList() {
		List<String> studentNames = new ArrayList<String>();							//create variable for student list of names
		StudentList studentList = new StudentList();									//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();									//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("Elizabeth Lockhart", studentNames.get(4));						//test case for pass/fail. We expect the fifth name to be ElizabethLockhart
	}
	
	@Test
	public void testGetStudentStevenFowler() {
		List<String> studentNames = new ArrayList<String>();							//create variable for student list of names
		StudentList studentList = new StudentList();									//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();									//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("Steven Fowler", studentNames.get(5));								//test case to see if the second value contains the name we expect
	}
	
	@Test
	public void testGetStudentVikasSharmaList() {
		List<String> studentNames = new ArrayList<String>();							//create variable for student list of names
		StudentList studentList = new StudentList();									//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();									//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("Vikas Sharma", studentNames.get(6));								//test case pass/fail if the sixth name for the student list is Vikas Sharma
	}
	
	@Test
	public void testGetStudentFayaz() {
		List<String> studentNames = new ArrayList<String>();							//create variable for student list of names
		StudentList studentList = new StudentList();									//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();									//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("Fayaz Shaikh", studentNames.get(8));							    //test case to see if the second value contains the name we expect
	}
	
	//Test the list of student names and ensure we get back the name value we expect at the correct/specific point in the list
	@Test
	public void testGetStudentAustenSeamans() {
		List<String> studentNames = new ArrayList<String>();							//create variable for student list of names
		StudentList studentList = new StudentList();									//instantiate the StudentList object so we can access it's methods and properties
		studentNames = studentList.getStudentsNames();									//populate the studentNames list with the actual values in the StudentsList object
		assertEquals("Austen Seamans", studentNames.get(10));							//test case for pass/fail. We expect the first name to be Austen. Remember arrays start their count at 0 not 1.
	}
	
	
	//Module 6 Test Case Area
	//Test each student profile to ensure it can be retrieved and accessed
	
	@Test
	public void testGetStudent1Profile() {
		TestStudent1_Playlist testStudent1Playlist = new TestStudent1_Playlist();						//instantiating the variable for a specific student
		Student TestStudent1 = new Student("TestStudent1", testStudent1Playlist.StudentPlaylist());		//creating populated student object
		assertEquals("TestStudent1", TestStudent1.getName());											//test case pass/fail line - did the name match what you expected?
	}
	
	@Test
	public void testGetStudent2Profile() {
		TestStudent2_Playlist testStudent2Playlist = new TestStudent2_Playlist();
		Student TestStudent2 = new Student("TestStudent2", testStudent2Playlist.StudentPlaylist());
		assertEquals("TestStudent2", TestStudent2.getName());
	}
	
	//Module 6 - Add your unit test case here to check for your profile after you have added it to the StudentList
	
	@Test
	public void testGetStevenFowlerProfile() {
		StevenFowler_Playlist stevenFowlerPlaylist = new StevenFowler_Playlist(); 						//Instantiate Playlist
		Student stevenFowler = new Student("Steven Fowler", stevenFowlerPlaylist.StudentPlaylist());	//Create Student
		assertEquals("Steven Fowler", stevenFowler.getName());											//Make sure names are equal
	}
	
	@Test
	public void testGetChrisAubutProfile() {
		ChrisAubut_Playlist testChrisAubutPlaylist = new ChrisAubut_Playlist();						    //instantiating Chris Aubut's playlist
		Student chrisAubut = new Student("Chris Aubut", testChrisAubutPlaylist.StudentPlaylist());		//creating Chris Aubut student object with their playlist
		assertEquals("Chris Aubut", chrisAubut.getName());											    //testing student's name in object is correct
	}
	
	@Test
	public void testGetJustinNelsonProfile() {
		JustinNelson_Playlist justinNelsonPlaylist = new JustinNelson_Playlist();						//instantiating the variable for Justin Nelson's playlist
		Student justinNelson = new Student("Justin Nelson", justinNelsonPlaylist.StudentPlaylist());	//creating populated student object
		assertEquals("Justin Nelson", justinNelson.getName());											//test case pass/fail line - did the name match what you expected?
	}

	public void testGetElizabethLockhartProfile() {
		ElizabethLockhart_Playlist testElizabethLockhartPlaylist = new ElizabethLockhart_Playlist();						//instantiating the variable for a specific student
		Student elizabethLockhart = new Student("Elizabeth Lockhart", testElizabethLockhartPlaylist.StudentPlaylist());		//creating populated student object
		assertEquals("Elizabeth Lockhart", elizabethLockhart.getName());											//test case pass/fail line - did the name match what you expected?
	}
	
	@Test
	public void testGetEsmeraldaMonteparoProfile() {
		EsmeraldaMonteparo_Playlist esmeraldaMonteparoPlaylist = new EsmeraldaMonteparo_Playlist(); 						//Instantiate Playlist
		Student esmeraldaMonteparo = new Student("Esmeralda Monteparo", esmeraldaMonteparoPlaylist.StudentPlaylist());		//Create Student
		assertEquals("Esmeralda Monteparo", esmeraldaMonteparo.getName());													//Make sure names are equal
	}
}
