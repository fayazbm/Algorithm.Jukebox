package snhu.jukebox.playlist;

import java.util.ArrayList;
import java.util.LinkedList;

public class Student {

	private String name;
	private ArrayList<PlayableSong> playlist;
	
	public Student(String name, ArrayList<PlayableSong> playlist) {
		this.name = name;
		this.playlist = playlist;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public ArrayList<PlayableSong> getPlaylist() {
		return playlist;
	}

	public void setPlaylist(ArrayList<PlayableSong> playlist) {
		this.playlist = playlist;
	}
}
