package snhu.jukebox.playlist;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;


public class Jukebox {
    
	static ArrayList<PlayableSong> playlist = new ArrayList<PlayableSong>();
    PlayableSong current;
    
    Jukebox() {
    }

    public ArrayList<PlayableSong> play(String studentPlaylistRequested) {
    	StudentList studentProfile = new StudentList();
    	Student student = studentProfile.GetStudentProfile(studentPlaylistRequested);
    	
    	playlist = student.getPlaylist();
    	for(PlayableSong song:playlist) {
    		current = song;
    	
	        if(current != null) {
	            current.play();
	        }
    	}
        return playlist;
    }
    
    public void playNext(int i) {
        if(current instanceof Song) {
            // If we are currently playing a song, get the next one
            getNextSong(i);
        } 
    }
    
    public void getNextSong(int i) {
        current = playlist.get(i+1);
        if(current != null) {
            current.play();
        }
    }
}
