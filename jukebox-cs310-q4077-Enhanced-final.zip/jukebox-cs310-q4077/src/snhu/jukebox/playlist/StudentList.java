package snhu.jukebox.playlist;

import snhu.student.playlists.*;

import java.util.ArrayList;
import java.util.List;

public class StudentList {

	public StudentList(){
	}

	public List<String> getStudentsNames() {
		ArrayList<String> studentNames = new ArrayList<String>();
		
		String StudentName1 = "TestStudent1Name";
		studentNames.add(StudentName1);
		
		String StudentName2 = "TestStudent2Name";
		studentNames.add(StudentName2);
		
		//Module 5 Code Assignment
		//Add your name to create a new student profile
		//Use template below and put your name in the areas of 'StudentName'
		//String StudentName3 = "TestStudent3Name";
		//studentNames.add(StudentName3);
		
		String StudentName3 = "Stephan Berry";
		studentNames.add(StudentName3);

		String ChrisAubut = "Chris Aubut";
		studentNames.add(ChrisAubut);
		
		String ElizabethLockhart = "Elizabeth Lockhart";
		studentNames.add(ElizabethLockhart);
		
		String StudentName6 = "Steven Fowler";
		studentNames.add(StudentName6);
		
		String StudentName7 = "Vikas Sharma";
		studentNames.add(StudentName7);
		
		String StudentName8 = "James Pyle";
		studentNames.add(StudentName8);

		String StudentName9 = "Fayaz Shaikh";
		studentNames.add(StudentName9);
		
		String StudentName10 = "Justin Nelson";
		studentNames.add(StudentName10);
		
		String StudentName11 = "Austen Seamans";
		studentNames.add(StudentName11);
		
		String StudentName12 = "Esmeralda Monteparo";
		studentNames.add(StudentName12);
		
		return studentNames;
	}

	public Student GetStudentProfile(String student){
		Student emptyStudent = null;
	
		switch(student) {
		   case "TestStudent1_Playlist":
			   TestStudent1_Playlist testStudent1Playlist = new TestStudent1_Playlist();
			   Student TestStudent1 = new Student("TestStudent1", testStudent1Playlist.StudentPlaylist());
			   return TestStudent1;
			   
		   case "TestStudent2_Playlist":
			   TestStudent2_Playlist testStudent2Playlist = new TestStudent2_Playlist();
			   Student TestStudent2 = new Student("TestStudent2", testStudent2Playlist.StudentPlaylist());
			   return TestStudent2;
			   
			   
		   //Module 6 Code Assignment - Add your own case statement for your profile. Use the above case statements as a template.
		   
		   case "StevenFowler_Playlist":
			   StevenFowler_Playlist stevenFowlerPlaylist = new StevenFowler_Playlist();
			   Student stevenFowler = new Student("Steven Fowler", stevenFowlerPlaylist.StudentPlaylist());
			   return stevenFowler;
			   
			   
		   case "VikasSharma_Playlist":
			   VikasSharma_Playlist vikasSharmaPlaylist = new VikasSharma_Playlist();
			   Student vikasSharma = new Student("Vikas Sharma", vikasSharmaPlaylist.StudentPlaylist());
			   return vikasSharma;
			   
		   case "FayazShaikh_Playlist":
			   FayazShaikh_Playlist fayazShaikh_Playlist = new FayazShaikh_Playlist();
			   Student fayazShaikh = new Student("Fayaz Shaikh", fayazShaikh_Playlist.StudentPlaylist());
			   return fayazShaikh;	 
			   
		   case "ChrisAubut_Playlist":
			   ChrisAubut_Playlist chrisAubut_Playlist = new ChrisAubut_Playlist();
			   Student chrisAubut = new Student("Chris Aubut", chrisAubut_Playlist.StudentPlaylist());
			   return chrisAubut;

		   case "JustinNelson_Playlist":
			   JustinNelson_Playlist justinNelsonPlaylist = new JustinNelson_Playlist();
			   Student justinNelson = new Student("Justin Nelson", justinNelsonPlaylist.StudentPlaylist());
			   return justinNelson;

		   case "ElizabethLockhart_Playlist":
			   ElizabethLockhart_Playlist elizabethLockhart_Playlist = new ElizabethLockhart_Playlist();
			   Student elizabethLockhart = new Student("Elizabeth Lockhart", elizabethLockhart_Playlist.StudentPlaylist());
			   return elizabethLockhart;
			   
		   case "AustenSeamans_Playlist":
			   AustenSeamans_Playlist AustenSeamansPlaylist = new AustenSeamans_Playlist();
			   Student austenSeamans = new Student("Austen Seamans", AustenSeamansPlaylist.StudentPlaylist());
			   return austenSeamans;
			   
		   case "EsmeraldaMonteparo_Playlist":
			   EsmeraldaMonteparo_Playlist esmeraldaMonteparoPlaylist = new EsmeraldaMonteparo_Playlist();
			   Student esmeraldaMonteparo = new Student("Esmeralda Monteparo", esmeraldaMonteparoPlaylist.StudentPlaylist());
			   return esmeraldaMonteparo;

		}
		return emptyStudent;
	}
}
