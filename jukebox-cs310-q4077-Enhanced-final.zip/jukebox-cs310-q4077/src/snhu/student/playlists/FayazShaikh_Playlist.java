package snhu.student.playlists;

import java.util.ArrayList;
import java.util.LinkedList;

import music.artist.Coldplay;
import music.artist.TheChainsmokers;
import music.artist.U2;
import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;

public class FayazShaikh_Playlist {
	public ArrayList<PlayableSong> StudentPlaylist(){
		
		ArrayList<PlayableSong> playlist = new ArrayList<PlayableSong>();
		ArrayList<Song> chainSmokersTracks = new ArrayList<Song>();
	    TheChainsmokers theChainsmokers = new TheChainsmokers();
	    ArrayList<Song> coldplayTracks = new ArrayList<Song>();
	    Coldplay coldplay = new Coldplay();
	    U2 u2 = new U2();
	    ArrayList<Song> u2Tracks = new ArrayList<Song>();
	    
	    chainSmokersTracks = theChainsmokers.getTheChainsmokersSongs();
	    coldplayTracks = coldplay.getColdplaySongs();
	    u2Tracks = u2.getU2Songs();
	    
		playlist.addAll(chainSmokersTracks);
		playlist.addAll(coldplayTracks);
		playlist.addAll(u2Tracks);
		
	    return playlist;
		}
}
