package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;
import java.util.ArrayList;
import java.util.LinkedList;

public class VikasSharma_Playlist {

	public ArrayList<PlayableSong> StudentPlaylist() {

		ArrayList<PlayableSong> playlist = new ArrayList<PlayableSong>();
		ArrayList<Song> queenTracks = new ArrayList<Song>();
		Queen queen = new Queen();

		queenTracks = queen.getQueenSongs();

		playlist.add(queenTracks.get(0));
		playlist.add(queenTracks.get(1));

		return playlist;
	}
}
