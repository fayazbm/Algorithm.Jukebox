package snhu.student.playlists;

import java.util.ArrayList;
import java.util.LinkedList;

import music.artist.EricChurch;
import music.artist.SoundGarden;
import music.artist.TheMarcusKingBand;
import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;

public class StevenFowler_Playlist {
	public ArrayList<PlayableSong> StudentPlaylist() {

		// Instantiate Playlist
		ArrayList<PlayableSong> playlist = new ArrayList<PlayableSong>();

		// Instantiate Track List For Eric Church
		ArrayList<Song> ericChurchTracks = new ArrayList<Song>();
		EricChurch ericChurch = new EricChurch();

		// Get Songs For Eric Church
		ericChurchTracks = ericChurch.getEricChurchSongs();

		// Add the first and second songs to playlist
		playlist.add(ericChurchTracks.get(0));
		playlist.add(ericChurchTracks.get(1));

		// Instantiate Track List For The Marcus King Band
		ArrayList<Song> theMarcusKingBandTracks = new ArrayList<Song>();
		TheMarcusKingBand theMarcusKingBand = new TheMarcusKingBand();
		// Get Songs For The Marcus King Band
		theMarcusKingBandTracks = theMarcusKingBand.getTheMarcusKingBandSongs();

		// Add the first three songs to playlist
		playlist.add(theMarcusKingBandTracks.get(0));
		playlist.add(theMarcusKingBandTracks.get(1));
		playlist.add(theMarcusKingBandTracks.get(2));

		// Instantiate Track List For Soundgarden
		ArrayList<Song> soundGardenTracks = new ArrayList<Song>();
		SoundGarden soundGarden = new SoundGarden();
		// Get Songs For Soundgarden
		soundGardenTracks = soundGarden.getSoundGardenSongs();
		// Add the first two songs to playlist
		playlist.add(soundGardenTracks.get(0));
		playlist.add(soundGardenTracks.get(1));

		return playlist;
	}
}
