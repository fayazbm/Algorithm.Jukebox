package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Personalized playlist for Chris Aubut.
 */
public class ChrisAubut_Playlist {
    
	public ArrayList<PlayableSong> StudentPlaylist(){
	
		// create a playlist
		ArrayList<PlayableSong> playlist = new ArrayList<PlayableSong>();
		
		// initialize Chainsmokers' tracks and get the band
		ArrayList<Song> theChainsmokersTracks = new ArrayList<Song>();
		TheChainsmokers TheChainsmokersBand = new TheChainsmokers();
	    
		// initialize Night Club's tracks and get the band
	    ArrayList<Song> nightClubTracks = new ArrayList<Song>();
	    NightClub nightClubBand = new NightClub();
	    
	    // initialize Pig's tracks and get the band
	    ArrayList<Song> pigTracks = new ArrayList<Song>();
	    Pig pigBand = new Pig();
		
	    // fill each band's tracks
	    theChainsmokersTracks = TheChainsmokersBand.getTheChainsmokersSongs();
	    nightClubTracks = nightClubBand.getNightClubSongs();
	    pigTracks = pigBand.getPigSongs();
		
	    // add tracks to the playlist
		playlist.add(pigTracks.get(0));
		playlist.add(nightClubTracks.get(1));
		playlist.add(pigTracks.get(1));
		playlist.add(theChainsmokersTracks.get(0));
		playlist.add(nightClubTracks.get(0));
		playlist.add(pigTracks.get(2));
	
		// return the playlist
		return playlist;

	}
}
