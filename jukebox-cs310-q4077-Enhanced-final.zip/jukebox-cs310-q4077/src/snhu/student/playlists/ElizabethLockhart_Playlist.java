package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;
import java.util.ArrayList;
import java.util.LinkedList;

public class ElizabethLockhart_Playlist {
	public ArrayList<PlayableSong> StudentPlaylist(){
		
		ArrayList<PlayableSong> playlist = new ArrayList<PlayableSong>();
		
		ArrayList<Song> coldplayTracks = new ArrayList<Song>();
		Coldplay coldplay = new Coldplay();
		coldplayTracks = coldplay.getColdplaySongs();
		
		playlist.add(coldplayTracks.get(0));
		playlist.add(coldplayTracks.get(1));
		
		
		ArrayList<Song> theChainsmokersTracks = new ArrayList<Song>();
		TheChainsmokers theChainsmokers = new TheChainsmokers();
		theChainsmokersTracks = theChainsmokers.getTheChainsmokersSongs();
		
		playlist.add(theChainsmokersTracks.get(0));
		playlist.add(theChainsmokersTracks.get(1));
		
		
		ArrayList<Song> u2Tracks = new ArrayList<Song>();
		U2 u2 = new U2();
		u2Tracks = u2.getU2Songs();
		
		playlist.add(u2Tracks.get(0));
		playlist.add(u2Tracks.get(1));
		
		
	    return playlist;
		}

}
