package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;
import java.util.ArrayList;
import java.util.LinkedList;

public class JustinNelson_Playlist {
    
	public ArrayList<PlayableSong> StudentPlaylist(){
		// The playlist that will be populated and returned
		ArrayList<PlayableSong> playlist = new ArrayList<PlayableSong>();
		
		// Get all Sound Garden songs
		ArrayList<Song> soundGardenTracks = new ArrayList<Song>();
	    SoundGarden soundGardenBand = new SoundGarden();
	    soundGardenTracks = soundGardenBand.getSoundGardenSongs();
		
	    // Add Black Hole Sun to my playlist
		playlist.add(soundGardenTracks.get(0));
		// Add Pretty Noose to my playlist
		playlist.add(soundGardenTracks.get(3));
		
		// Get all U2 songs
	    U2 u2Band = new U2();
		ArrayList<Song> u2Tracks = new ArrayList<Song>();
	    u2Tracks = u2Band.getU2Songs();
		
	    // Add Sunday Bloody Sunday to my playlist
		playlist.add(u2Tracks.get(0));
		// Add Bullet in the Blue Sky to my playlist
		playlist.add(u2Tracks.get(1));
		// Add Red Hill Town to my playlist
		playlist.add(u2Tracks.get(3));
		
	    return playlist;
	}
}
