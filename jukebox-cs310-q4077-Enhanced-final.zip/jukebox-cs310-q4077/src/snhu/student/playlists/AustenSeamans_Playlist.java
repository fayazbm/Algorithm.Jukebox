package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;
import java.util.ArrayList;
import java.util.LinkedList;

public class AustenSeamans_Playlist {
    
	public ArrayList<PlayableSong> StudentPlaylist(){ 
	
	//creates PlayableSong, Song and Motorhead objects.
		ArrayList<PlayableSong> playlist = new ArrayList<PlayableSong>(); 
	ArrayList<Song> motorheadTracks = new ArrayList<Song>();
    Motorhead motorheadBand = new Motorhead();
	
    //Calls the getMotorheadSongs function in order to load the arrayList. Adds that list incrementally to the playlist LinkedList. 
    motorheadTracks = motorheadBand.getMotorheadSongs();
	
	playlist.add(motorheadTracks.get(0));
	playlist.add(motorheadTracks.get(1));
	
	//creates BlackSabbath and Song objects. Also calls the getBlackSabbathSongs function to load up the blackSabbathTracks Song object.
    BlackSabbath blackSabbathBand = new BlackSabbath();
	ArrayList<Song> blackSabbathTracks = new ArrayList<Song>();
	blackSabbathTracks = blackSabbathBand.getBlackSabbathSongs();
	
	//Adds three songs to the playlist from the blackSabbathTracks object. 
	playlist.add(blackSabbathTracks.get(0));
	playlist.add(blackSabbathTracks.get(1));
	playlist.add(blackSabbathTracks.get(2));
	
    return playlist;
	}
}
