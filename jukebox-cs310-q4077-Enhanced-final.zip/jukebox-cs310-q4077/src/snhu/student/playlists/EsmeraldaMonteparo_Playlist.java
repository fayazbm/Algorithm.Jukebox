package snhu.student.playlists;

import java.util.ArrayList;
import java.util.LinkedList;

import music.artist.GreenDay;
import music.artist.Nickelback;
import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;


public class EsmeraldaMonteparo_Playlist {
	public ArrayList<PlayableSong> StudentPlaylist(){
		
	//Instantiate Playlist
		ArrayList<PlayableSong> playlist = new ArrayList<PlayableSong>();
	
	//Instantiate Track List For Green Day
	ArrayList<Song> greenDayTracks = new ArrayList<Song>();
	GreenDay greenDay = new GreenDay();
    
	//Get Songs For Green Day
	greenDayTracks = greenDay.getGreenDaySongs();
	
    //Add the first and second songs to playlist
	playlist.add(greenDayTracks.get(0));
	playlist.add(greenDayTracks.get(1));
	
	
 
	//Instantiate Track List For Nickelback
	ArrayList<Song> NickelbackTracks = new ArrayList<Song>();   
	Nickelback nickelback = new Nickelback();;
	
	//Get Nickelback songs
	NickelbackTracks = nickelback.getNickelbackSongs();
	
	//Add the first and second songs to playlist
	playlist.add(NickelbackTracks.get(0));
	playlist.add(NickelbackTracks.get(1));
		
    return playlist;
	}
}
