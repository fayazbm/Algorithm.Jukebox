package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;
import java.util.ArrayList;
import java.util.LinkedList;

public class StephanBerry_Playlist {

	public LinkedList<PlayableSong> StudentPlaylist(){
		
		LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
		ArrayList<Song> u2Tracks = new ArrayList<Song>();
		ArrayList<Song> soundgardenTracks = new ArrayList<Song>();
		U2 u2 = new U2();
		SoundGarden soundgarden = new SoundGarden();
		
	    u2Tracks = u2.getU2Songs();
	    soundgardenTracks = soundgarden.getSoundGardenSongs();
		
		playlist.add(u2Tracks.get(0));
		playlist.add(u2Tracks.get(1));
		playlist.add(u2Tracks.get(2));
		playlist.add(u2Tracks.get(3));
		
		playlist.add(soundgardenTracks.get(0));
		playlist.add(soundgardenTracks.get(1));
		playlist.add(soundgardenTracks.get(2));
		playlist.add(soundgardenTracks.get(3));
				
	    return playlist;
		}
}
