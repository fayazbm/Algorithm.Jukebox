package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class SoundGarden {

	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public SoundGarden() {
    }
    
    public ArrayList<Song> getSoundGardenSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                  //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Black Hole Sun", "Soundgarden");              
    	 Song track2 = new Song("Rusty Cage", "Soundgarden");
    	 Song track3 = new Song("The Day I Tried to Live", "Soundgarden");
    	 Song track4 = new Song("Pretty Noose", "Soundgarden");                 //Create another song
         this.albumTracks.add(track1);                                          //Add the first song to song list for Soundgarden
         this.albumTracks.add(track2);
         this.albumTracks.add(track3);
         this.albumTracks.add(track4);                                          //Add the fourth song to song list for Soundgarden 
         return albumTracks;                                                    //Return the songs for Soundgarden in the form of an ArrayList
    }
}
