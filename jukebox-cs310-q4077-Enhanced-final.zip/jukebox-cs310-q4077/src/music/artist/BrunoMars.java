package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class BrunoMars {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public BrunoMars() {
    }
    
    public ArrayList<Song> getBrunoMarsSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                   //Instantiate the album so we can populate it below
    	 Song track1 = new Song("24k Magic", "Bruno Mars");             		//Create a song
         Song track2 = new Song("Finesse", "Bruno Mars");         				//Create another song
         this.albumTracks.add(track1);                                          //Add the first song to song list for Bruno Mars
         this.albumTracks.add(track2);                                          //Add the second song to song list for  Bruno Mars
         return albumTracks;                                                    //Return the songs for Bruno Mars in the form of an ArrayList
    }

}
