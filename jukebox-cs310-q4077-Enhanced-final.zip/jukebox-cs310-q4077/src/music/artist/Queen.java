package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class Queen {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public Queen() {															//Added the play list for Queen with their songs 
    }
    
    public ArrayList<Song> getQueenSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                   //Instantiate the album so we can populate it below
    	 Song track1 = new Song("We Will Rock You", "Queen");                   //Create a song
         Song track2 = new Song("We Are The Champion", "Queen");                //Create another song
         this.albumTracks.add(track1);                                          //Add the first song to song list for Queen
         this.albumTracks.add(track2);                                          //Add the second song to song list for Queen 
         return albumTracks;                                                    //Return the songs for Queen in the form of an ArrayList
    }

}
