package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class U2 {

	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public U2() {
    }
    
    public ArrayList<Song> getU2Songs() {
    	
    	 albumTracks = new ArrayList<Song>();                                   //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Sunday Bloody Sunday", "U2");                  //Create a song
         Song track2 = new Song("Bullet in the Blue Sky", "U2");
         Song track3 = new Song("New Years Day", "U2");
         Song track4 = new Song("Red Hill Town", "U2");                         //Create another song
         this.albumTracks.add(track1);                                          //Add the first song to song list for U2
         this.albumTracks.add(track2);
         this.albumTracks.add(track3);
         this.albumTracks.add(track4);                                          //Add the fourth song to song list for U2 
         return albumTracks;                                                    //Return the songs for U2 in the form of an ArrayList
    }
}
