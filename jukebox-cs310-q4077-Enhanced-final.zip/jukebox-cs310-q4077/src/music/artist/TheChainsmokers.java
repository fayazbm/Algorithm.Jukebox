package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class TheChainsmokers {

	ArrayList<Song> albumTracks;
    String albumTitle;

    public TheChainsmokers() {
    }

    public ArrayList<Song> getTheChainsmokersSongs() {

    	 albumTracks = new ArrayList<Song>();                                   //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Dont Let me Down", "Daya");             //Create a song
         Song track2 = new Song("Closer", "Halsey");         //Create another song
         this.albumTracks.add(track1);                                          //Add the first song to song list for the Chainsmokers
         this.albumTracks.add(track2);                                          //Add the second song to song list for the Chainsmokers
         return albumTracks;                                                    //Return the songs for the Chainsmokers in the form of an ArrayList
    }
}
