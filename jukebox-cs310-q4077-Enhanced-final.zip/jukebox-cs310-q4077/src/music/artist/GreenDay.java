package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class GreenDay {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public GreenDay() {
    }
    
    public ArrayList<Song> getGreenDaySongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                   //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Boulevard of Broken Dreams", "Green Day");     //Create song
    	 Song track2 = new Song("American Idiot", "Green Day");         	    //Create another song
         this.albumTracks.add(track1);                                          //Add the first song to song list for the Beatles
         this.albumTracks.add(track2);                                          //Add the second song to song list for the Beatles 
         return albumTracks;                                                    //Return the songs for the Beatles in the form of an ArrayList
    }
}
